import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forogot-password',
  templateUrl: './forogot-password.component.html',
  styleUrls: ['./forogot-password.component.scss']
})
export class ForogotPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
