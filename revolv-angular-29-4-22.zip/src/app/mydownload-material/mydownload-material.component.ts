import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydownload-material',
  templateUrl: './mydownload-material.component.html',
  styleUrls: ['./mydownload-material.component.scss']
})
export class MydownloadMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
