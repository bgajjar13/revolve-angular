import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mynotifications',
  templateUrl: './mynotifications.component.html',
  styleUrls: ['./mynotifications.component.scss']
})
export class MynotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
