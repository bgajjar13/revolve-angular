import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myfavorites',
  templateUrl: './myfavorites.component.html',
  styleUrls: ['./myfavorites.component.scss']
})
export class MyfavoritesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
