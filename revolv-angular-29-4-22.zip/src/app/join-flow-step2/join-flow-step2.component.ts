import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-flow-step2',
  templateUrl: './join-flow-step2.component.html',
  styleUrls: ['./join-flow-step2.component.scss']
})
export class JoinFlowStep2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
