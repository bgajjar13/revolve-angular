import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mysettings',
  templateUrl: './mysettings.component.html',
  styleUrls: ['./mysettings.component.scss']
})
export class MysettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
