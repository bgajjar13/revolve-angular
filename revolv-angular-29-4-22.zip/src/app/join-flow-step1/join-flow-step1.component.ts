import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-flow-step1',
  templateUrl: './join-flow-step1.component.html',
  styleUrls: ['./join-flow-step1.component.scss']
})
export class JoinFlowStep1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
