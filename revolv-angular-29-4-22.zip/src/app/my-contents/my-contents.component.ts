import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-contents',
  templateUrl: './my-contents.component.html',
  styleUrls: ['./my-contents.component.scss']
})
export class MyContentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
