import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-step-welcome',
  templateUrl: './join-step-welcome.component.html',
  styleUrls: ['./join-step-welcome.component.scss']
})
export class JoinStepWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
