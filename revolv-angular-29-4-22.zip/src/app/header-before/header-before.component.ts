import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-before',
  templateUrl: './header-before.component.html',
  styleUrls: ['./header-before.component.scss']
})
export class HeaderBeforeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
