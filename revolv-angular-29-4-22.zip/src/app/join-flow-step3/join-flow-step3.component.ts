import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-flow-step3',
  templateUrl: './join-flow-step3.component.html',
  styleUrls: ['./join-flow-step3.component.scss']
})
export class JoinFlowStep3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
