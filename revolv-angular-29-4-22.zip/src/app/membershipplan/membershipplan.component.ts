import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membershipplan',
  templateUrl: './membershipplan.component.html',
  styleUrls: ['./membershipplan.component.scss']
})
export class MembershipplanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
