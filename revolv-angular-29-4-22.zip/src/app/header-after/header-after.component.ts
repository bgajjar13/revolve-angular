import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-after',
  templateUrl: './header-after.component.html',
  styleUrls: ['./header-after.component.scss']
})
export class HeaderAfterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
