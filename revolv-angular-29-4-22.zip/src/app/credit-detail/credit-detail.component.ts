import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-detail',
  templateUrl: './credit-detail.component.html',
  styleUrls: ['./credit-detail.component.scss']
})
export class CreditDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
